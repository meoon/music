'use strict';

describe('Theme', function() {
  require('./theme');
  require('./view');
});

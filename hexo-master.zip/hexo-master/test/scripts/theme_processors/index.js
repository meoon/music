'use strict';

describe('Theme processors', function() {
  require('./config');
  require('./i18n');
  require('./source');
  require('./view');
});

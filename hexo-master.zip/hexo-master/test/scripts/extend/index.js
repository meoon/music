'use strict';

describe('Extend', function() {
  require('./console');
  require('./deployer');
  require('./filter');
  require('./generator');
  require('./helper');
  require('./migrator');
  require('./processor');
  require('./renderer');
  require('./tag');
});

'use strict';

describe('Box', function() {
  require('./box');
  require('./file');
});

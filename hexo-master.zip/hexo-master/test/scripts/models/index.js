'use strict';

describe('Models', function() {
  require('./asset');
  require('./cache');
  require('./category');
  require('./moment');
  require('./page');
  require('./post');
  require('./post_asset');
  require('./tag');
});

'use strict';

describe('Generators', function() {
  require('./asset');
  require('./page');
  require('./post');
});

'use strict';

describe('Renderers', function() {
  require('./json');
  require('./plain');
  require('./swig');
  require('./yaml');
});
